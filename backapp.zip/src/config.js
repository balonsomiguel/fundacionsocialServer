export default {
    SEED: 'gruposocial'
};
