import app from './app.js'
import './database.js'

app.listen(3000);

console.log('Server listen on port',3000)